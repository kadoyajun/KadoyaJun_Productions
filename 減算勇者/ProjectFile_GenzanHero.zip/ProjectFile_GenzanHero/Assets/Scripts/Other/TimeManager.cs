using UnityEngine;

public class TimeManager : MonoBehaviour
{
    private static TimeManager instance;
    public static TimeManager Instance => instance;

    private int minute = 0;
    private float seconds = 0f;

    public delegate void TimeUpdateEvent(int minute, float seconds);
    public event TimeUpdateEvent OnTimeUpdate;

    private bool isCounting = false;

    void Awake()
    {
        if (instance == null)
        {
            instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }

    void Start()
    {
        StartCounting();
    }

    void FixedUpdate()
    {
        if (isCounting)
        {
            seconds += Time.deltaTime;
            if (seconds >= 60f)
            {
                minute++;
                seconds = seconds - 60;
            }

            // ���Ԃ��X�V���ꂽ���Ƃ��C�x���g�Œʒm
            OnTimeUpdate?.Invoke(minute, seconds);
        }
    }

    public void StartCounting()
    {
        isCounting = true;
    }

    public void StopCounting()
    {
        isCounting = false;
    }
}