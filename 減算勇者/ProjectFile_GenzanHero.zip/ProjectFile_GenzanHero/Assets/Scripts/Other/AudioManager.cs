using Genzan;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

[System.Serializable]
public class Sound02
{
    public string name1;
    public AudioClip clip1;
    [HideInInspector]
    public AudioSource source1;
}

public class AudioManager : MonoBehaviour
{
    private static AudioManager instance;

    // BGM�p��AudioSource��ݒ�
    [SerializeField] 
    private AudioSource bgmAudioSource;
    // SE�p��AudioSource���Z�b�g���ꂽGameObject��ݒ�
    [SerializeField] 
    private GameObject seAudioSourcePrefab;
    [SerializeField]
    private int seAudioSourcePoolSize = 15;
    private List<AudioSource> seAudioSourcePool;

    public AudioMixerGroup bgmMixerGroup;
    public AudioMixerGroup seMixerGroup;

    // �g�p����AudioMixer��ݒ�
    [SerializeField] private AudioMixer audioMixer;
    // BGM�̉��ʂ�ݒ肷��Slider��ݒ�
    [SerializeField] private Slider bgmSlider;
    // SE�̉��ʂ�ݒ肷��Slider��ݒ�
    [SerializeField] private Slider seSlider;

    // BGM�p��Sound�z��
    public Sound02[] bgmSounds;
    // SE�p��Sound�z��
    public Sound02[] seSounds;

    string currentSceneName;

    public bool safeArea = false;
    
    // AudioManager.Instance.�֐����@�ŏ��X�Ăяo���Ă��������B
    // public�Őݒ肵�ČĂяo���ł���
    public static AudioManager Instance => instance; 

    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
            //DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }

    void Start()
    {
        InitializeAudioSources();
        SetupSliderListeners();
        LoadSliderPositions();
        currentSceneName = SceneManager.GetActiveScene().name;
        PlaySceneBGM(currentSceneName);  
    }

    void InitializeAudioSources()
    {
        // BGM AudioSource �̐ݒ�
        if (bgmAudioSource != null)
        {
            if (bgmSounds.Length > 0 && bgmSounds[0] != null)
            {
                bgmAudioSource.outputAudioMixerGroup = bgmMixerGroup;
                bgmAudioSource.loop = true;
            }
            else
            {
                Destroy(bgmAudioSource);
            }
        }

        // SE AudioSource �v�[���̏�����
        seAudioSourcePool = new List<AudioSource>();
        for (int i = 0; i < seAudioSourcePoolSize; i++)
        {
            GameObject audioSourceObject = Instantiate(seAudioSourcePrefab, transform);
            AudioSource audioSource = audioSourceObject.GetComponent<AudioSource>();
            audioSource.outputAudioMixerGroup = seMixerGroup;
            audioSourceObject.SetActive(false);
            seAudioSourcePool.Add(audioSource);
        }
    }

    // PlayBGM(�ݒ肵��BGM��)�ŌĂяo���\
    public void PlayBGM(string name)
    {
        Sound02 newBGM = FindSound(bgmSounds, name);
        if (newBGM != null && newBGM.clip1 != null)
        {
            bgmAudioSource.clip = newBGM.clip1;
            bgmAudioSource.Play();
        }
    }

    // PlaySE(�ݒ肵��SE��)�ŌĂяo���\
    public void PlaySE(string name)
    {
        Sound02 sound = FindSound(seSounds, name);
        if (sound != null)
        {
            AudioSource audioSource = GetAvailableAudioSource();
            if (audioSource != null)
            {
                StartCoroutine(PlaySECoroutine(audioSource, sound));
            }
        }
    }

    // SE�I����AudioSource��False
    IEnumerator PlaySECoroutine(AudioSource audioSource, Sound02 sound)
    {
        audioSource.clip = sound.clip1;
        audioSource.gameObject.SetActive(true);
        audioSource.Play();

        yield return new WaitForSeconds(sound.clip1.length);

        audioSource.gameObject.SetActive(false);
    }

    // Pool���痘�p�\��AudioSource���擾
    AudioSource GetAvailableAudioSource()
    {
        foreach (AudioSource audioSource in seAudioSourcePool)
        {
            if (!audioSource.gameObject.activeInHierarchy)
            {
                return audioSource;
            }
        }
        return null;
    }


    Sound02 FindSound(Sound02[] sounds, string name)
    {
        return System.Array.Find(sounds, sound => sound.name1 == name);
    }

    // �ۑ����Ă���BGM��SE�̉��ʂ�ǂݍ���
    private void LoadSliderPositions()
    {
        if (PlayerPrefs.HasKey("BGM"))
        {
            float bgmVolume = PlayerPrefs.GetFloat("BGM");
            bgmSlider.value = bgmVolume;
        }

        if (PlayerPrefs.HasKey("SE"))
        {
            float seVolume = PlayerPrefs.GetFloat("SE");
            seSlider.value = seVolume;
        }
    }



    void SetupSliderListeners()
    {
        if (bgmSlider != null)
        {
            bgmSlider.onValueChanged.AddListener(OnBGMVolumeChanged);
        }

        if (seSlider != null)
        {
            seSlider.onValueChanged.AddListener(OnSEVolumeChanged);
        }
    }

    // BGM�̉��ʂ�ύX�����ۂɌĂяo�����
    void OnBGMVolumeChanged(float value)
    {
        value = Mathf.Clamp01(value);
        float decibel = 20f * Mathf.Log10(value);
        decibel = Mathf.Clamp(decibel, -80, 0f);
        audioMixer.SetFloat("BGM", decibel);
        SaveSliderPosition();
    }

    // SE�̉��ʂ�ύX�����ۂɌĂяo�����
    void OnSEVolumeChanged(float value)
    {
        value = Mathf.Clamp01(value);
        float decibel = 20f * Mathf.Log10(value);
        decibel = Mathf.Clamp(decibel, -80, 0f);
        audioMixer.SetFloat("SE", decibel);
        SaveSliderPosition();
        PlaySE("TantativeSE");
    }

    // SE��BGM�̉��ʂ�ύX�����ہA�Ăяo���ĕύX��ۑ�����
    private void SaveSliderPosition()
    {
        PlayerPrefs.SetFloat("BGM", bgmSlider.value);
        PlayerPrefs.SetFloat("SE", seSlider.value);
        PlayerPrefs.Save();
    }

    // �V�[���ɉ�����BGM��ύX
    void PlaySceneBGM(string sceneName)
    {
        switch (sceneName)
        {
            case "TitleScene":
                PlayBGM("TitleBGM");
                break;
            case "Stage1Scene":
                PlayBGM("Stage1BGM");
                break;
            case "Stage2Scene":
                PlayBGM("Stage2BGM");
                break;
            default:
                break;
        }
    }

    // �{�X�펞�Ăяo���Ăяo���B
    // PlayBGM("BGM��"); ���Ăяo�����Ƃł��\�B
    public void bossAreaBGM()
    {
        switch (currentSceneName)
        {
            case "Stage1Scene":
                PlayBGM("BossBGM");
                break;
            case "Stage2Scene":
                PlayBGM("MaouBGM");
                break;
            default:
                break;
        }
        
    }

    // BGM���~�߂����ꍇ�Ăяo��
    public void stopBGM()
    {
        bgmAudioSource.Stop();
    }

    // ��{�I��PlayBGM("BGM��")�ő�p�\
    public void restartBGM()
    {
        if (!bgmAudioSource.isPlaying)
        {
            bgmAudioSource.Play();
        }
    }
}