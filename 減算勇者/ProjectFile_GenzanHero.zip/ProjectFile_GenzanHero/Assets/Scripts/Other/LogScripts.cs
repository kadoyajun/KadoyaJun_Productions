using System;
using System.Collections.Generic;
using System.Text;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class LogScripts : MonoBehaviour
{
    public enum LogType
    {
        All,
        Area,
        Event,
    }

    // ���O�o��
    [SerializeField]
    private TextMeshProUGUI textoutput;
    // ���O�f�[�^
    private List<string> allLogs;
    // �G���A�̃��O�f�[�^
    private List<string> areaLogs;
    // �C�x���g�f�[�^
    private List<string> eventLogs;
    // ���ݕ\������Log�̃^�C�v
    [SerializeField]
    private LogType CurrentLogType = LogType.All;
    // �e���O�f�[�^�ۑ���
    [SerializeField]
    private int allLogDate = 10;
    [SerializeField]
    private int areaLogDate = 10;
    [SerializeField]
    private int eventLogDate = 10;
    // �c�X�N���[��
    [SerializeField]
    private Scrollbar verticalScrollBar;
    private StringBuilder logtextStringBuilder;

    // Start is called before the first frame update
    void Start()
    {
        allLogs = new List<string>();
        areaLogs = new List<string>();
        eventLogs = new List<string>();
        logtextStringBuilder = new StringBuilder();
    }

    /// ���O�e�L�X�g�̒ǉ�
    public void AddLogText(string logText, LogType logType)
    {
        // ���O�̎�ނ𔻕ʂ��ALog��ǉ�
        allLogs.Add(logText);
        if (logType == LogType.Event)
        {
            eventLogs.Add(logText);
        }
        // ���O�ۑ����𒴂����ꍇ�폜
        if (allLogs.Count > allLogDate)
        {
            allLogs.RemoveRange(0, allLogs.Count - allLogDate);
        }
        else if (areaLogs.Count > areaLogDate)
        {
            eventLogs.RemoveRange(0, areaLogs.Count - areaLogDate);
        }
        else if (eventLogs.Count > eventLogDate)
        {
            eventLogs.RemoveRange(0, eventLogs.Count - eventLogDate);
        }
        // ���O�̕\��
        if (CurrentLogType == LogType.All || CurrentLogType == logType)
        {
            ViewLogtext();
        }
    }

    /// ���O�e�L�X�g�̕\��
    public void ViewLogtext()
    {
        logtextStringBuilder.Clear();
        List<String> selectedLogs = new List<string>();
        // ���O�̎�ނɉ����ĕ\�����郍�O��؂�ւ���
        if (CurrentLogType == LogType.All)
        {
            selectedLogs = allLogs;
        }
        else if (CurrentLogType == LogType.Area)
        {
            selectedLogs = areaLogs;
        }
        else if (CurrentLogType == LogType.Event)
        {
            selectedLogs = eventLogs;
        }
        foreach (var log in selectedLogs)
        {
            logtextStringBuilder.Append(Environment.NewLine + log);
        }
        textoutput.text = logtextStringBuilder.ToString().TrimEnd();
        updateVertical();
    }

    /// �X�N���[���o�[�ʒu�̍X�V  
    public void updateVertical()
    {
        verticalScrollBar.value = 0f;
    }
}
