using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneStateManager : MonoBehaviour
{
    public enum SceneState
    {
        notStageData,
        isStageData
    }

    public SceneState defaultState = SceneState.notStageData;

    public SceneState currentScene = SceneState.notStageData;

    void Start()
    {
        string currentSceneName = SceneManager.GetActiveScene().name;
        if (currentSceneName == "TitleScene")
        {
            // �^�C�g���V�[���ɖ߂����ꍇ�A�O��ۑ����ꂽ�V�[����Ԃ����[�h����
            currentScene = LoadSceneState();
        }
        else
        {
            // ���̑��̃V�[���̏ꍇ�A�V�[�����Ɋ�Â��ď�Ԃ�ݒ肵�A�ۑ�����
            currentScene = GetSceneStateFromName(currentSceneName);
            SaveSceneState();
        }
    }

    public void SaveSceneState()
    {
        PlayerPrefs.SetInt("SceneState", (int)currentScene);
        PlayerPrefs.Save();
    }

    public SceneState LoadSceneState()
    {
        int defaultValue = (int)SceneState.notStageData;
        int stateValue = PlayerPrefs.GetInt("SceneState", defaultValue);
        return (SceneState)stateValue;
    }

    public SceneState GetSceneStateFromName(string sceneName)
    {
        if (sceneName == "TitleScene")
        {
            return LoadSceneState();
        }
        else
        {
            return SceneState.isStageData;
        }
    }
}