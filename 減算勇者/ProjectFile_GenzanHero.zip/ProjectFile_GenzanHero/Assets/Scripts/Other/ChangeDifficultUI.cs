using UnityEngine;

public class ChangeDifficultyUI : MonoBehaviour
{
    // ��Փx
    public enum Difficulty
    {
        Easy,
        Normal,
        Hard
    }

    private static ChangeDifficultyUI instance;

    public static ChangeDifficultyUI Instance => instance;

    public Difficulty currentDifficulty;

    public void Awake()
    {
        LoadDifficulty();
    }

    public void Start()
    {
        if (instance == null)
        {
            instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }

    // ��Փx���C�[�W�[�ɐݒ�
    public void ChangeEasyDifficulty()
    {
        currentDifficulty = Difficulty.Easy;
        // PlayerPrefs�Ƀt���O��ݒ肷��
        PlayerPrefs.SetInt("StartFromBeginning", 1);
        PlayerPrefs.Save();
        SaveDifficulty();
    }

    // ��Փx���m�[�}���ɐݒ�
    public void ChangeNormalDifficulty()
    {
        currentDifficulty = Difficulty.Normal;
        // PlayerPrefs�Ƀt���O��ݒ肷��
        PlayerPrefs.SetInt("StartFromBeginning", 1);
        PlayerPrefs.Save();
        SaveDifficulty();
    }

    // ��Փx���n�[�h�ɐݒ�
    public void ChangeHardDifficulty()
    {
        currentDifficulty = Difficulty.Hard;
        // PlayerPrefs�Ƀt���O��ݒ肷��
        PlayerPrefs.SetInt("StartFromBeginning", 1);
        PlayerPrefs.Save();
        SaveDifficulty();
    }

    // ��Փx�̕ۑ�
    public void SaveDifficulty()
    {
        PlayerPrefs.SetInt("Difficulty", (int)currentDifficulty);
        PlayerPrefs.Save();
    }

    // ��Փx�̃��[�h
    public void LoadDifficulty()
    {
        if (!PlayerPrefs.HasKey("currentDifficulty")) 
        {
            int difficultyIndex = PlayerPrefs.GetInt("Difficulty", (int)Difficulty.Normal);
            currentDifficulty = (Difficulty)difficultyIndex;
        }
    }
}
