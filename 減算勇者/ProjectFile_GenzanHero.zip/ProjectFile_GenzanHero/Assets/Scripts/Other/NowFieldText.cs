using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;

public class NowFieldText : MonoBehaviour
{
    [SerializeField]
    private TextMeshProUGUI nowFieldText;

    private void Start()
    {
        string currentSceneName = SceneManager.GetActiveScene().name;
        NowSceneName(currentSceneName);
    }

    // �V�[���ɉ�����BGM��ύX
    void NowSceneName(string sceneName)
    {
        switch (sceneName)
        {
            case "Stage1Scene":
                nowFieldText.text = "�X���C���̂���";
                break;
            case "Stage2Scene":
                nowFieldText.text = "�܂����̂���";
                break;
            default:
                nowFieldText.text = "�L�����v";
                break;
        }
    }
}
