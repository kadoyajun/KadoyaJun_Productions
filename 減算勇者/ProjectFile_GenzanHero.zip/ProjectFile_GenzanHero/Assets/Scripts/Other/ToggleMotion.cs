using Genzan;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class ToggleMotion : MonoBehaviour
{
    public GameManager gameManager;
    public ItemSourceData[] itemData;
    public TextMeshProUGUI itemNameText;
    public TextMeshProUGUI explanationText;

    private void Start()
    {
        var toggles = GetComponentsInChildren<Toggle>();
        for (int i = 0; i < toggles.Length; i++)
        {
            var toggle = toggles[i];
            toggle.GetComponentInChildren<TextMeshProUGUI>().text = itemData[i].ItemName;
            int index = i; // �����_�����ł̎Q�Ɨp�ɃC���f�b�N�X���L���v�`������
            toggle.onValueChanged.AddListener((state) => Change(index, state));
        }
    }

    public void Change(int toggleIndex, bool state)
    {
        if (state)
        {
            Debug.Log("Toggle " + toggleIndex + " ��ON�ɂȂ�܂���");
            if (toggleIndex < itemData.Length && itemData[toggleIndex] != null)
            {
                Debug.Log("Item ID: " + itemData[toggleIndex]._id);
                Debug.Log("Item Type: " + itemData[toggleIndex]._itemType);
                Debug.Log("Item Name: " + itemData[toggleIndex]._itemName);
                Debug.Log("Item Explanation: " + itemData[toggleIndex]._itemExplanation);
                Debug.Log("Item Level: " + itemData[toggleIndex]._Level);
                Debug.Log("Item Armor: " + itemData[toggleIndex]._armor);

                //gameManager.level += itemData[toggleIndex]._Level;

                if (explanationText != null && itemNameText != null)
                {
                    itemNameText.text = itemData[toggleIndex].ItemName;
                    explanationText.text = itemData[toggleIndex].ItemExplanation;
                }
                else
                {
                    Debug.LogWarning("ExplanationText���ݒ肳��Ă��܂���");
                }
            }
            else
            {
                Debug.LogWarning("Toggle " + toggleIndex + " �ɑΉ�����ItemSourceData������܂���");
            }
        }
        else
        {
            Debug.Log("Toggle" + toggleIndex + "��OFF�ɂȂ�܂���");
            //gameManager.level -= itemData[toggleIndex]._Level;
            itemNameText.text = "�����тȂ�";
            explanationText.text = "�����тȂ�";
        }
    }
}