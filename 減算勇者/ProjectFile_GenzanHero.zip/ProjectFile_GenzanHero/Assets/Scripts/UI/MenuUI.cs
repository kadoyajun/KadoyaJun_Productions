using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

namespace Genzan
{
    public class MenuUI : MonoBehaviour
    {
        // UI���J�����ۍŏ��ɑI�������Button
        [SerializeField]
        private Selectable SelectedButton;
        [SerializeField]
        private GameObject _gameClearUI;
        [SerializeField]
        private GameObject _gameOverUI;

        private static MenuUI instance;

        public bool IsMenu = false;

        // �V���O���g�������A�N�Z�X���
        public static MenuUI Instance => instance;

        private void Awake()
        {
            if (instance == null)
            {
                instance = this;
            }
            else
            {
                Destroy(gameObject);
            }
        }

        private void Start()
        {
            IsMenu = false;

            this.gameObject.SetActive(false);
        }

        // MenuUI�Ăяo��
        public void OnMenu(InputAction.CallbackContext context)
        {
            if (context.started)
            {
                GameManager gM = transform.root.GetComponent<GameManager>();
                if (gM.gameState != GameManager.GameState.StageClear && gM.gameState != GameManager.GameState.GameOver && gM.gameState != GameManager.GameState.StartAnimation)
                {
                    if (IsMenu == false)
                    {
                        IsMenu = true;
                        PauseGame();
                        AudioManager.Instance.PlaySE("SubmitSE");
                        this.gameObject.SetActive(true);
                        SelectedButton.Select();
                        Time.timeScale = 0;
                    }
                    else
                    {
                        IsMenu = true;
                        if (IsOption)
                        {
                            IsOption = false;
                            OptionUI.Instance.OnHide();
                        }
                        else if (IsExit)
                        {
                            IsExit = false;
                            ExitUI.Instance.OnHide();
                        }
                        else if (IsEquipment)
                        {
                            IsEquipment = false;
                            EquipmentUI.Instance.OnHide();
                        }
                        else
                        {
                            AudioManager.Instance.PlaySE("SubmitSE");
                        }
                        IsMenu = false;

                        ResumeGame();
                        this.gameObject.SetActive(false);
                        Time.timeScale = 1;
                    }
                }
            }
        }

        public void Resume()
        {
            IsMenu = false;
            ResumeGame();
            AudioManager.Instance.PlaySE("SubmitSE");
            this.gameObject.SetActive(false);
            Time.timeScale = 1;
        }

        public bool IsEquipment { get; private set; } = false;

        // OptionUI�Ăяo��
        public void OnEquipment()
        {
            if (!IsEquipment)
            {
                IsEquipment = true;
                EquipmentUI.Instance.OnShow();
            }
            else
            {
                IsEquipment = false;
                EquipmentUI.Instance.OnHide();
                SelectedButton.Select();
            }
        }

        public bool IsOption { get; private set; } = false;

        // OptionUI�Ăяo��
        public void OnOption()
        {
            if (!IsOption)
            {
                IsOption = true;
                AudioManager.Instance.PlaySE("SubmitSE");
                OptionUI.Instance.OnShow();
            }
            else
            {
                IsOption = false;
                AudioManager.Instance.PlaySE("SubmitSE");
                OptionUI.Instance.OnHide();
                SelectedButton.Select();
            }
        }

        public bool IsExit { get; private set; } = false;

        // ExitUI�Ăяo��
        public void OnExit()
        {
            if (!IsExit)
            {
                IsExit = true;
                AudioManager.Instance.PlaySE("SubmitSE");
                ExitUI.Instance.OnShow();
            }
            else
            {
                IsExit = false;
                AudioManager.Instance.PlaySE("SubmitSE");
                ExitUI.Instance.OnHide();
                SelectedButton.Select();
            }
        }

        public void LoadStageSelectScene()
        {
            ResumeGame();
            AudioManager.Instance.PlaySE("SubmitSE");
            SceneManager.LoadScene("StageSelectScene");
            Time.timeScale = 1;
        }
        private void ResumeGame()
        {
            GameManager gM = transform.root.GetComponent<GameManager>();
            IsMenu = false;
            gM.gameState = GameManager.GameState.Game;
            this.gameObject.SetActive(false);
        }

        private void PauseGame()
        {
            GameManager gM = transform.root.GetComponent<GameManager>();
            IsMenu = true;
            gM.gameState = GameManager.GameState.Pause;
            this.gameObject.SetActive(true);
            SelectedButton.Select();
        }
    }

    



}
