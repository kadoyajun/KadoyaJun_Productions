using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ThereDataUI : MonoBehaviour
{
    [SerializeField]
    private Selectable firstSelected;
    [SerializeField]
    private Selectable closedSelected;
    [SerializeField]
    private SceneStateManager sceneStateManager;
    [SerializeField]
    private TiteUI titeUI;

    public void OnShow()
    {
        this.gameObject.SetActive(true);
        firstSelected.Select();
    }

    public void OnClose()
    {
        this.gameObject.SetActive(false);
        closedSelected.Select();
    }

    public void dleteData()
    {
        PlayerPrefs.DeleteKey("SceneState");
        PlayerPrefs.DeleteKey("Level");
        PlayerPrefs.DeleteKey("Stage1Clear");
        sceneStateManager.currentScene = sceneStateManager.defaultState;
        Debug.Log("�f�[�^�폜");
        OnClose();
        titeUI.showChangeDifficultyUI();
    }

}
