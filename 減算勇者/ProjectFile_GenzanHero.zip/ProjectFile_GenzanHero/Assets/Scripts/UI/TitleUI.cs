using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class TiteUI : MonoBehaviour
{
    [SerializeField]
    private GameObject selectMenu;
    [SerializeField]
    private Selectable startButton;
    [SerializeField]
    private GameObject _startButton;
    [SerializeField]
    private OptionUI optionUI;
    [SerializeField]
    private Selectable Selectbutton;
    [SerializeField]
    private Selectable DifficultyButton;
    [SerializeField]
    private Selectable noDataUIButton;
    [SerializeField]
    private Selectable thereDataUIButton;
    [SerializeField]
    private StageSelectUI stageSelectUI;
    [SerializeField]
    private GameObject changeDifficultUI;
    [SerializeField]
    private NowDataUI nowDataUI;
    [SerializeField]
    private ThereDataUI thereDataUI;
    [SerializeField]
    private NoDataUI noDataUI;
    [SerializeField]
    private SceneStateManager sceneStateManager;

    Animator animator;

    static readonly int showId = Animator.StringToHash("Show");

    // Start is called before the first frame update
    private void Start()
    {
        animator = GetComponent<Animator>();
        startButton.Select();
    }

    // �V�[���ǂݍ���
    public void LoadScene(string sceneName)
    {
        SceneManager.LoadScene(sceneName);
    }

    public void playDataConfirmation()
    {
        
    }

    public void OnStart()
    {
        switch (sceneStateManager.currentScene)
        {
            case SceneStateManager.SceneState.isStageData:
                thereDataUI.OnShow();
                break;
            case SceneStateManager.SceneState.notStageData:
                showChangeDifficultyUI();
                break;
        }
    }

    public void OnContinue()
    {
        switch (sceneStateManager.currentScene)
        {
            case SceneStateManager.SceneState.isStageData:
                nowDataUI.OnShow();
                break;
            case SceneStateManager.SceneState.notStageData:
                noDataUI.OnShow();
                break;
        }
    }

    // Level�̃f�[�^�����Z�b�g���鏈��
    public void deleteLevel()
    {
        // �f�[�^������ꍇ
        if (PlayerPrefs.HasKey("Level"))
        {
            PlayerPrefs.DeleteKey("Level");
        }
        else
        {

        }
    }

    public void showStageSelectUIt()
    {
        if (PlayerPrefs.HasKey("Level"))
        {
            stageSelectUI.showStageSelect();
        }
    }

    // ChangeDifficultyUi���J��
    public void showChangeDifficultyUI()
    {
        changeDifficultUI.SetActive(true);
        DifficultyButton.Select();
    }

    // ChangeDifficultyUi�����
    public void closeChangeDifficultyUI()
    {
        changeDifficultUI.SetActive(false);
        Selectbutton.Select();
    }

    // 
    public void OnStartButtonClicked()
    {
        
    }

    // OptionUI���J��
    public void ShowOption()
    {
        optionUI.OnShow();
    }

    // OptionUi�����
    public void CloseOption()
    {
        OptionUI.Instance.OnHide();
        Selectbutton.Select();
    }

    public void goSelect()
    {
        animator.SetTrigger(showId);
        StartCoroutine(OnShow());
    }

    IEnumerator OnShow()
    {
        // 4�b�ҋ@
        yield return new WaitForSeconds(3);
        // �{�^���I��
        Selectbutton.Select();
    }

    //�Q�[���I��
    public void EndGame()
    {
#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;//�Q�[���v���C�I��
#else
    Application.Quit();//�Q�[���v���C�I��
#endif
    }
}
