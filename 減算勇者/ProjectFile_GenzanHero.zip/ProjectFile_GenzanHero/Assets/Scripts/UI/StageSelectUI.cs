using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Experimental.Rendering;
using UnityEngine.UI;

public class StageSelectUI : MonoBehaviour
{
    [SerializeField]
    private Selectable firstSelected;
    // ��Փx�I���ɖ߂�ꍇ
    [SerializeField]
    private Selectable selectWhenClosedButton;
    // �^�C�g���ɖ߂�ꍇ
    [SerializeField]
    private Selectable selectTitleButton;
    [SerializeField]
    private GameObject changeDifficultyUI;

    public void showStageSelect()
    {
        changeDifficultyUI.SetActive(false);
        this.gameObject.SetActive(true);
        firstSelected.Select();
    }

    public void CloseStageSelect()
    {
        this.gameObject.SetActive(false);
        changeDifficultyUI.SetActive(true);
        selectWhenClosedButton.Select();
    }

    public void ShowTitle()
    {
        this.gameObject.SetActive(false);
        selectTitleButton.Select();
    }

}
