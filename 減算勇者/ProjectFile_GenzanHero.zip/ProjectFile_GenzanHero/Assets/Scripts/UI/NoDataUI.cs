using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class NoDataUI : MonoBehaviour
{
    [SerializeField]
    private Selectable firstSelected;
    [SerializeField]
    private Selectable closedSelected;
    [SerializeField]
    private SceneStateManager sceneStateManager;
    [SerializeField]
    private TiteUI titeUI;

    // UI��\��
    public void OnShow()
    {
        this.gameObject.SetActive(true);
        firstSelected.Select();
    }

    // UI���\��
    public void OnClose()
    {
        this.gameObject.SetActive(false);
        closedSelected.Select();
    }

    public void dataCreateGo()
    {
        titeUI.showChangeDifficultyUI();
        this.gameObject.SetActive(false);
    }
}
