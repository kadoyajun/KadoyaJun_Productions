using System.Collections;
using System.Collections.Generic;
using System.Security.Cryptography;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class NowDataUI : MonoBehaviour
{
    [SerializeField]
    private TextMeshProUGUI nowLevel;
    [SerializeField]
    private Selectable firstSelected;
    [SerializeField]
    private Selectable colosedSelect;
    [SerializeField]
    private TextMeshProUGUI nowDifficult;
    [SerializeField]
    ChangeDifficultyUI changeDifficultyUI;

    public void Start()
    {
        int NowLevelData = PlayerPrefs.GetInt("Level", 0);
        string nowDifficultyData = changeDifficultyUI.currentDifficulty.ToString();
        nowLevel.text = "���񂴂��̃��x�� : " + NowLevelData;
        nowDifficult.text = "�Ȃ񂢂� : " + nowDifficultyData;
    }

    public  void OnShow()
    {
        this.gameObject.SetActive(true);
        firstSelected.Select();
    }

    public void OnClose()
    {
        this.gameObject.SetActive(false);
        colosedSelect.Select();
    }
}
