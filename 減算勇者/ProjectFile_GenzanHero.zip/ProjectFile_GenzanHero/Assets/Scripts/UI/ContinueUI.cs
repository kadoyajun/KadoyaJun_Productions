using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Experimental.Rendering;
using UnityEngine.UI;

public class ContinueUI : MonoBehaviour
{
    [SerializeField]
    private Selectable firstSelected;
    [SerializeField]
    private Selectable backedTitlebutton;

    public void showContinueUI()
    {
        this.gameObject.SetActive(true);
        firstSelected.Select();
    }

    public void closeContinueUI()
    {
        this.gameObject.SetActive(false);
        backedTitlebutton.Select();
    }
}
