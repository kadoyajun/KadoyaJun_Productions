﻿using System.Collections;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UI;

public class FirstTextUI : MonoBehaviour
{
    public Selectable selectButton;

    // Menu中動けないようにとりあえずInputSysemを指定
    [SerializeField]
    public InputActionProperty[] _inputActions;

    private InputAction[] _inputActionArray;

    void Start()
    {
        // PlayerPrefsのフラグをチェックする
        if (PlayerPrefs.GetInt("StartFromBeginning", 0) == 1)
        {
            // パネルを表示する
            this.gameObject.SetActive(true);
            _inputActionArray = new InputAction[_inputActions.Length];
            inputActionDisable();
            StartCoroutine(selectButtonTime());
            // フラグをリセットする
            PlayerPrefs.SetInt("StartFromBeginning", 0);
            PlayerPrefs.Save();
        }
        else
        {
            // パネルを非表示のままにするs
            this.gameObject.SetActive(false);
        }
    }

    public void OnClose()
    {
        AudioManager.Instance.PlaySE("SubmitSE");
        this.gameObject.SetActive(false);
        inputActionEnable();
    }

    IEnumerator selectButtonTime()
    {
        yield return new WaitForSeconds(2);
        selectButton.Select();
    }

    void inputActionDisable()
    {
        if (_inputActionArray == null)
        {
            _inputActionArray = new InputAction[_inputActions.Length];
        }

        for (int i = 0; i < _inputActions.Length; i++)
        {
            _inputActionArray[i] = _inputActions[i].action;
            if (_inputActionArray[i] != null)
            {
                _inputActionArray[i].Disable();
            }
        }
    }

    void inputActionEnable()
    {
        if (_inputActionArray == null)
        {
            _inputActionArray = new InputAction[_inputActions.Length];
            for (int i = 0; i < _inputActions.Length; i++)
            {
                _inputActionArray[i] = _inputActions[i].action;
            }
        }

        foreach (var inputAction in _inputActionArray)
        {
            if (inputAction != null)
            {
                inputAction.Enable();
            }
        }
    }
}