using Genzan;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class ExitUI : MonoBehaviour
{
    [SerializeField]
    private Selectable SelectButton;

    private static ExitUI instance;


    // �V���O���g�������A�N�Z�X���
    public static ExitUI Instance => instance;

    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }

    private void Start()
    {
        this.gameObject.SetActive(false);
    }

    // UI���J��
    public void OnShow()
    {
        this.gameObject.SetActive(true);
        SelectButton.Select();
    }

    // UI�����
    public void OnHide()
    {
        this.gameObject.SetActive(false);
    }

    // Scene�ڍs
    public void Exit(string sceneName)
    {
        AudioManager.Instance.PlaySE("SubmitSE");
        Time.timeScale = 1;
        SceneManager.LoadScene(sceneName);
    }
}
