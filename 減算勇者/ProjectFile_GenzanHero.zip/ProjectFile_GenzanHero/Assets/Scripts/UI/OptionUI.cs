using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class OptionUI : MonoBehaviour
{
    [SerializeField]
    private Selectable selectedButton;

    private static OptionUI instance;

    // �V���O���g�������A�N�Z�X���
    public static OptionUI Instance => instance;

    public void Awake()
    {
        if (Instance == null)
        {
            instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }

    public void Start()
    {
        this.gameObject.SetActive(false);
    }

    // UI���J��
    public void OnShow()
    {
        this.gameObject.SetActive(true);
        selectedButton.Select();
    }

    // UI�����
    public void OnHide()
    {
        this.gameObject.SetActive(false);
    }
}
