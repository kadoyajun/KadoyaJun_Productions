namespace Genzan
{
    public static class CNum
    {
        public const int ROW = 10;
        public const int COLUMN = 10;
        public const int UP = 0;
        public const int DOWN = 1;
        public const int LEFT = 2;
        public const int RIGHT = 3;
        public const int DIRECTIONCOUNT = 4;
        public const uint STARTLEVEL = 100;
    }
}