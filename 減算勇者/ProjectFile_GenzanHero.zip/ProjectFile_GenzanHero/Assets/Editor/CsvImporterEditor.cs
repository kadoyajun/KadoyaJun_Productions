using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

[CustomEditor(typeof(CsvImporter))]
public class CsvImpoterEditor : Editor
{
    public override void OnInspectorGUI()
    {
        var csvImpoter = target as CsvImporter;
        DrawDefaultInspector();

        if (GUILayout.Button("�G�f�[�^���쐬"))
        {
            SetCsvDataToScriptableObject(csvImpoter);
        }
    }

    void SetCsvDataToScriptableObject(CsvImporter csvImporter)
    {
        if (csvImporter.csvFile == null)
        {
            Debug.LogWarning(csvImporter.name + " : CSV�t�@�C�����Z�b�g����Ă��܂���B");
            return;
        }

        string csvText = csvImporter.csvFile.text;

        string[] afterParse = csvText.Split('\n');

        for (int i = 1; i < afterParse.Length; i++)
        {
            string[] parseByComma = afterParse[i].Split(',');

            int column = 0;
            if (parseByComma[column] == "")
            {
                continue;
            }

            // �s����ID�Ƃ��ăt�@�C�����쐬
            string fileName = "enemyData_" + i.ToString("D13") + ".asset";
            string path = "Assets/StatusConverter/CsvScripts/" + fileName;

            var enemyData = CreateInstance<EnemyData>();

            // �G�̖��O
            enemyData.enemyName = parseByComma[column];

            // ��Փx�C�[�W�[�ł̃��x��
            column += 1;
            enemyData.easyLevel = int.Parse(parseByComma[column]);

            // ��Փx�m�[�}���ł̃��x��
            column += 1;
            enemyData.nomalLevel = int.Parse(parseByComma[column]);

            // ��Փx�n�[�h�ł̃��x��
            column += 1;
            enemyData.hardLevel = int.Parse(parseByComma[column]);

            var asset = (EnemyData)AssetDatabase.LoadAssetAtPath(path, typeof(EnemyData));
            if (asset == null)
            {
                AssetDatabase.CreateAsset(enemyData, path);
            }
            else
            {
                EditorUtility.CopySerialized(enemyData, asset);
                AssetDatabase.SaveAssets();
            }
            AssetDatabase.Refresh();
        }
        Debug.Log(csvImporter.name + " : �G�f�[�^�̍쐬���������܂����B");
    }
}