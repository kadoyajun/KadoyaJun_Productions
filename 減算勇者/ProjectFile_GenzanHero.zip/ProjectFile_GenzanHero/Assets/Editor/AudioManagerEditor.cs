using UnityEngine;
using UnityEditor;

[CustomEditor(typeof(AudioManager))]
public class AudioManagerEditor : Editor
{
    public override void OnInspectorGUI()
    {
        DrawDefaultInspector();

        AudioManager audioManager = (AudioManager)target;

        if (GUILayout.Button("Sort BGM and SE Alphabetically"))
        {
            SortSounds(audioManager);
        }
    }

    private void SortSounds(AudioManager audioManager)
    {
        System.Array.Sort(audioManager.bgmSounds, (a, b) => string.Compare(a.name1, b.name1));
        System.Array.Sort(audioManager.seSounds, (a, b) => string.Compare(a.name1, b.name1));

        EditorUtility.SetDirty(audioManager);
    }
}