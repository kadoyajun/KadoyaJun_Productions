/**
	SpriteStudio6 Player for Unity

	Copyright(C) 1997-2021 Web Technology Corp.
	Copyright(C) CRI Middleware Co., Ltd.
	All rights reserved.
*/

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
#if UNITY_EDITOR
using UnityEditor;
#endif

[System.Serializable]
public partial class Script_SpriteStudio6_HolderAssetUnityNative : MonoBehaviour
{
	/* ----------------------------------------------- Variables & Properties */
	#region Variables & Properties
	public AnimationClip[] TableAnimationClip;
    #endregion Variables & Properties

    /* ----------------------------------------------- MonoBehaviour-Functions */
    #region MonoBehaviour-Functions
    //	void Awake()
    //	{
    //	}

    //	void Start()
    //	{
    //	}

    //	void Update()
    //	{
    //	}

    //	void LateUpdate()
    //	{
    //	}
    #endregion MonoBehaviour-Functions
    private Animator animator;
    private bool isAnimating = false;

    void Start()
    {
        animator = GetComponent<Animator>();
    }

   /* void Update()
    {
        if (!isAnimating && (Input.GetKeyDown(KeyCode.W) || Input.GetKeyDown(KeyCode.A) || Input.GetKeyDown(KeyCode.S) || Input.GetKeyDown(KeyCode.D)))
        {
            // �A�j���[�V�������Đ����łȂ��ꍇ�ɂ̂ݍĐ����܂�
            isAnimating = true;
            animator.SetBool("IsWalking", true);
            Invoke("StopAnimation", animator.GetCurrentAnimatorClipInfo(0).Length);
        }
    }
   */
    /*void StopAnimation()
    {
        // �A�j���[�V�������~���A��������ɖ߂��܂�
        animator.SetBool("IsWalking", false);
        isAnimating = false;
    }
    */
}