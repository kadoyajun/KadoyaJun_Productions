using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Video;

public class OPAnimation : MonoBehaviour
{
    [SerializeField]
    private GameObject opAnimation = null;
    [SerializeField]
    private GameObject rawImage = null;

    VideoPlayer videoPlayer;

    private float optime = 10.0f;

    // Start is called before the first frame update
    void Start()
    {        
        videoPlayer = GetComponent<VideoPlayer>();
        opAnimation.SetActive(true);
    }

    void Update()
    {
        optime -= Time.deltaTime;

        if (optime <= 0)
        {
            Destroy(opAnimation);
            Destroy(rawImage);
            // opAnimation.SetActive (false);
        }
    }
}
