using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Brock : MonoBehaviour
{
    [SerializeField]
    private GameObject brock;

    // �\������
    [SerializeField]
    private float gaugetimer = 0;
    // �\���I������
    [SerializeField]
    private float endtime = 15;

    // ����UI���\���ɐݒ肵�܂�
    public void Hide1()
    {
        brock.SetActive(false);
    }

    public void Show1()
    {
        brock.SetActive(true);
    }
    // Start is called before the first frame update
    void Start()
    {
        Hide1();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    private void FixedUpdate()
    {
        if (brock == true)
        {
            // �\�����Ă��鎞��
            gaugetimer += Time.deltaTime;
        }

        if (gaugetimer >= endtime)
        {
            Hide1();
        }
    }
}
