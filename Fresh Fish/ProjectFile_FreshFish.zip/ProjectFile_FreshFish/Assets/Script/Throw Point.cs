using UnityEngine;
using UnityEngine.InputSystem;

public class ThrowPoint : MonoBehaviour
{
    // �J�[�\���̈ړ����x
    [SerializeField]
    public float cursorSpeed = 4;
    // ���݂̈ړ����x
    float speed = 4;

    [SerializeField]
    Feed feed;

    [SerializeField]
    public float max = 0;
    [SerializeField]
    public float min = 800;

    private bool isMoveing = false;

    new Rigidbody2D rigidbody;

    // Start is called before the first frame update
    void Start()
    {
        rigidbody = GetComponent<Rigidbody2D>();

        speed = cursorSpeed;
    }

    // Update is called once per frame
    void Update()
    {
        // ���E�̐���
        Vector3 stickPos = transform.position;
        stickPos.x = Mathf.Clamp(stickPos.x, min, max);
        transform.position = stickPos;

        if (feed.isGetCopy == false)
        {
            if (isMoveing == true)
            {
                // �����x�^��
                var velocity = rigidbody.velocity;
                velocity.x = speed * -1;
                rigidbody.velocity = velocity;
            }
            else if (isMoveing == false)
            {
                var velocity = rigidbody.velocity;
                velocity.x = 0;
                rigidbody.velocity = velocity;
            }
        }

    }

    // Fire�A�N�V�����ɂ���ČĂяo�����
    public void OnFire(InputAction.CallbackContext context)
    {
        if (context.started)
        {
          //  Debug.Log("Fire!: started");

            isMoveing = true;
        }
        else if (context.performed)
        {
          //  Debug.Log("Fire!: performed");
        }
        else if (context.canceled)
        {
          //  Debug.Log("Fire!: canceled");

            isMoveing = false;
        }
    }
}
