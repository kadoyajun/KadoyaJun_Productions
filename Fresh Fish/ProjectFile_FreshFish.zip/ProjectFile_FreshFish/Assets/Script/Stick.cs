using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UI;

public class Stick : MonoBehaviour
{
    // �o�[�̏オ�鑬�x
    [SerializeField]
    public float upSpeed = 10;

    float speed = 10;

    private bool isUping = false;

    [SerializeField]
    public float max = 1080;
    [SerializeField]
    public float min = 540;

    new Rigidbody2D rigidbody;

    // Start is called before the first frame update
    void Start()
    {
        rigidbody = GetComponent<Rigidbody2D>();

        speed = upSpeed;
    }

    // Update is called once per frame
    void Update()
    {
        // �㉺�̐���
        Vector3 stickPos = transform.position;
        stickPos.y = Mathf.Clamp(stickPos.y, min, max);
        transform.position = stickPos;

        if (isUping == true)
        {
            // �����x�^��
            var velocity = rigidbody.velocity;
            velocity.y = speed * 7;
            rigidbody.velocity = velocity;
        }
        else if (isUping == false)
        {
            var velocity = rigidbody.velocity;
            velocity.y = speed * -3;
            rigidbody.velocity = velocity;
        }

        //Debug.Log(transform.position.y - 688);
    }

    public void OnHit(InputAction.CallbackContext context)
    {
        if (context.started)
        {
            isUping = true;
        }
        else if (context.performed)
        {
            isUping = false;
        }
        else if (context.canceled)
        {
            isUping = false;
        }
    }
}
