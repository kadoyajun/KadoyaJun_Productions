using UnityEngine;
using UnityEngine.InputSystem;
public class Feed : MonoBehaviour
{
    // �����n�_�̍��W
    [SerializeField]
    private GameObject throwPoint;

    // �a�̗������x
    [SerializeField]
    public float fallSpeed = 2;
    // ���݂̗������x
    float speed = 2;

    // �������
    private bool isFalling = false;
    // �Ԃ��������
    private bool isGet = false;

    public bool isGetCopy = false;

    new Rigidbody2D rigidbody;
    new BoxCollider2D collider2D;

    // Start is called before the first frame update
    void Start()
    {
        rigidbody = GetComponent<Rigidbody2D>();
        collider2D = GetComponent<BoxCollider2D>();

        speed = fallSpeed;
    }

    // Update is called once per frame
    void Update()
    {
        if (isGetCopy == false)
        {
            // Debug.Log(isGet);
            // �������
            if (isFalling == true)
            {
                var velocity = rigidbody.velocity;
                velocity.y = -speed;
                rigidbody.velocity = velocity;
            }
            // ������Ԃ��Ԃ����Ă�����
            else if (isFalling == false && isGet == true)
            {
                isGetCopy = true;

                var velocity = rigidbody.velocity;
                velocity.y = speed;
                rigidbody.velocity = velocity;

            }
            else
            {
                Vector3 position = throwPoint.transform.position;
                position.y -= 0.8f;
                transform.position = position;
            }
        }

        if (transform.position.y >= throwPoint.transform.position.y)
        {
            isGet = false;
            rigidbody.velocity = Vector3.zero;
            Vector3 position = throwPoint.transform.position;
            position.y -= 0.8f;
            transform.position = position;
        }
    }

    // Down�A�N�V�����ɂ���ČĂяo�����
    public void OnDown(InputAction.CallbackContext context)
    {
        if (context.started)
        {
            //  Debug.Log("Down!: started");

            isFalling = true;
        }
        else if (context.performed)
        {
            //  Debug.Log("Down!: performed");
        }
        else if (context.canceled)
        {
            //  Debug.Log("Down!: canceled");
        }
    }

    // �����蔻��
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Fish")
        {
            //Debug.Log("!!!");

            isFalling = false;
            isGet = true;

            collider2D.isTrigger = true;
        }
        else
        {
            isFalling = false;
        }
    }
}
