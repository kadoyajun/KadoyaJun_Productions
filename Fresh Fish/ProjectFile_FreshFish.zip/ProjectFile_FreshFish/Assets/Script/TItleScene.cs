using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

   public class TitleScene : MonoBehaviour
    {
        [SerializeField]
        private Selectable selectButton = null;
        void Start()
        {
            selectButton.Select();
        }

        public void OnStartButton()
        {
            SceneManager.LoadScene("FishingScene");
        }

        public void OnExitbutton()
        {
            Application.Quit();
        }
   }
    