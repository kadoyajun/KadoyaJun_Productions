<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<link rel="stylesheet" type="text/css" href="/style.css">
</head>
<body>
<div class="wrap">
<a href="/admin/event" class="back">戻る</a>
<h1>イベント情報更新</h1>
<form method="post" action="/admin/event/<?php echo e($event->id); ?>">
	<?php echo csrf_field(); ?>
	<?php echo method_field('put'); ?>
	<div class="input">
		<div>イベント名：<input type="text" name="title" value="<?php echo e($event->title); ?>"></div>
		<div>開催場所：<input type="text" name="place" value="<?php echo e($event->place); ?>"></div>
		<div>開催日時：<input type="date" name="event_date" value="<?php echo e($event->event_date); ?>"></div>
		<div class="submit"><input type="submit" value="保存"></div>
	</div>
</form>
</div>
</body>
</html><?php /**PATH C:\Users\juleo\laravel\gorin_completedversion\resources\views/admin/event/edit.blade.php ENDPATH**/ ?>