<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>
<h1>作成</h1>
<form method="post" action="/admin/worker">
	<?php echo csrf_field(); ?>
	氏名<input type="text" name="name">
	メールアドレス<input type="text" name="email">
	パスワード<input type="password" name="password">
	メモ<input type="text" name="memo">
	<input type="submit" value="登録">
</form>
</body>
</html><?php /**PATH C:\Users\juleo\laravel\laravel\resources\views/admin/worker/create.blade.php ENDPATH**/ ?>