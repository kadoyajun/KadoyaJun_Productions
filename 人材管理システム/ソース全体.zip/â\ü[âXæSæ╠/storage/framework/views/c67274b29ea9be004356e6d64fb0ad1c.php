<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <link rel="stylesheet" type="text/css" href="/style.css">
</head>
<body>
<div class="wrap">
<a href="/admin/dispatch" class="back">戻る</a>
<h1>派遣情報編集</h1>
<form method="post" action="/admin/dispatch/<?php echo e($dispatch->id); ?>">
    <?php echo csrf_field(); ?>
    <?php echo method_field('put'); ?>
    <div class="input">
        <select name="event_id" id="">
            <option value="" hidden>イベント名</option>
            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($event->id); ?>"><?php echo e($event->title); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <select name="worker_id" id="">
            <option value="" hidden>人材名</option>
            <?php $__currentLoopData = $workers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $worker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($worker->id); ?>"><?php echo e($worker->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <input type="submit" value="作成"></input>
    </div>
</form>
</div>
</body>
</html><?php /**PATH C:\Users\juleo\laravel\gorin_completedversion\resources\views/admin/dispatch/edit.blade.php ENDPATH**/ ?>