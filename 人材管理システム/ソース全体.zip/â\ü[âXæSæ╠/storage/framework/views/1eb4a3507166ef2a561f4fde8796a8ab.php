<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>
<h1>人材情報</h1>
<a href="/admin/worker/create">人材情報新規登録</a>
<table border="1">
	<tr>
		<th>氏名</th>
		<th>メールアドレス</th>
		<th></th>
		<th></th>
	</tr>
	<?php $__currentLoopData = $workers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $worker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<tr>
		<td><?php echo e($worker->name); ?></td>
		<td><?php echo e($worker->email); ?></td>
		<td><a href="#">編集</a></td>
		<td>
			<form method="post" action="/admin/worker/<?php echo e($worker->id); ?>" >
				<?php echo csrf_field(); ?>
				<?php echo method_field('delete'); ?>
				<input type="submit" value="削除">
			</form>			
		</td>

	</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</body>
</html><?php /**PATH C:\Users\juleo\laravel\laravel\resources\views/admin/worker/index.blade.php ENDPATH**/ ?>