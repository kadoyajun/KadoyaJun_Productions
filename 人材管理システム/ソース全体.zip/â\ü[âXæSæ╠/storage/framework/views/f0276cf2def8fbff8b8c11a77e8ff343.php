<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<link rel="stylesheet" type="text/css" href="/style.css">
</head>
<body>
<?php
    $eventId = array(null);
    foreach($dispatches as $dispatch){
        foreach($events as $event){
            if($dispatch->event_id == $event->id){
                array_push($eventId,$event->title);
                break;
            }
        }
    }
    $workerId = array(null);
    foreach($dispatches as $dispatch){
        foreach($workers as $worker){
            if($dispatch->worker_id == $worker->id){
                array_push($workerId, $worker->name);
                break;
            }
        }
    }
	$count = 1;
?>
<div class="wrap">
<a href="/admin/menu" class="back">戻る</a>
<h1>派遣情報</h1>
<a href="/admin/dispatch/create">派遣情報新規登録</a>
<table border="1" class="table">
	<tr>
		<th>イベント名</th>
		<th>人材名</th>
		<th></th>
		<th></th>
	</tr>
	<?php $__currentLoopData = $dispatches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dispatch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<tr>
        <td><?php echo e($eventId[$count]); ?></td>
        <td><?php echo e($workerId[$count]); ?></td>
		<td><a href="/admin/dispatch/<?php echo e($dispatch->id); ?>/edit">編集</a></td>
		<td>
			<form method="post" action="/admin/dispatch/<?php echo e($dispatch->id); ?>">
				<?php echo csrf_field(); ?>
				<?php echo method_field('delete'); ?>
				<input type="submit" value="削除">
			</form>			
		</td>

	</tr>
	<?php $count++; ?>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</div>
</body>
</html><?php /**PATH C:\Users\juleo\laravel\gorin_completedversion\resources\views/admin/dispatch/index.blade.php ENDPATH**/ ?>