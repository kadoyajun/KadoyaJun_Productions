<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>
<h1>イベント情報更新</h1>
<form method="post" action="/admin/event/<?php echo e($event->id); ?>">
	<?php echo csrf_field(); ?>
	<?php echo method_field('put'); ?>
	イベント名：<input type="text" name="title" value="<?php echo e($event->title); ?>">
	開催場所：<input type="text" name="place" value="<?php echo e($event->place); ?>">
	開催日時：<input type="text" name="event_date" value="<?php echo e($event->event_date); ?>">
	<input type="submit" value="保存">
</form>
</body>
</html><?php /**PATH C:\Users\juleo\laravel\laravel\resources\views/admin/event/edit.blade.php ENDPATH**/ ?>