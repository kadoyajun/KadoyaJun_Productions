<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>
<h1>メニュー</h1>
<a href="/admin/logout">ログアウト</a>
<a href="/admin/event">イベント情報</a>
<a href="/admin/worker">人材情報</a>
<a href="#">派遣情報</a>
</body>
</html><?php /**PATH C:\Users\juleo\laravel\laravel\resources\views/admin/menu.blade.php ENDPATH**/ ?>