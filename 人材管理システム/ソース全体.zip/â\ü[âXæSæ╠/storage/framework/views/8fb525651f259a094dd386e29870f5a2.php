<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>
<h1>作成</h1>
<form method="post" action="/admin/event">
	<?php echo csrf_field(); ?>
	イベント名<input type="text" name="title"><br>
	開催場所<input type="text" name="place"><br>
	開催日時<input type="date" name="event_date"><br>
	<input type="submit" value="登録">
</form>
</body>
</html><?php /**PATH C:\Users\juleo\laravel\laravel\resources\views/admin/event/create.blade.php ENDPATH**/ ?>