<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>
<h1>管理者ログイン</h1>
<form method="post" action="/admin/login_check">
	<?php echo csrf_field(); ?>
	ID:<input type="text" name="email">
	PASS<input type="password" name="password">
	<input type="submit" value="ログイン">
	
</form>
</body>
</html><?php /**PATH C:\Users\juleo\laravel\laravel\resources\views/admin/index.blade.php ENDPATH**/ ?>