<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<link rel="stylesheet" type="text/css" href="/style.css">
</head>
<body>
<div class="wrap">
<a href="/admin/menu" class="back">戻る</a>
<h1>人材情報</h1>
<a href="/admin/worker/create">人材情報新規登録</a>
<table border="1" class="table">
	<tr>
		<th>氏名</th>
		<th>メールアドレス</th>
		<th></th>
		<th></th>
	</tr>
	<?php $__currentLoopData = $workers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $worker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<tr>
		<td><?php echo e($worker->name); ?></td>
		<td><?php echo e($worker->email); ?></td>
		<td><a href="/admin/worker/<?php echo e($worker->id); ?>/edit">編集</a></td>
		<td>
			<form method="post" action="/admin/worker/<?php echo e($worker->id); ?>" >
				<?php echo csrf_field(); ?>
				<?php echo method_field('delete'); ?>
				<input type="submit" value="削除">
			</form>			
		</td>

	</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</div>
</body>
</html><?php /**PATH C:\Users\juleo\laravel\gorin_completedversion\resources\views/admin/worker/index.blade.php ENDPATH**/ ?>