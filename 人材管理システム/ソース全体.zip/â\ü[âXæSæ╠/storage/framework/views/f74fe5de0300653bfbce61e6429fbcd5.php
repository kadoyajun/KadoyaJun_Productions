<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="/style.css">
	<title></title>
</head>
<body>
<div class="wrap">
	<h1>メニュー</h1>
	<a href="/admin/logout">ログアウト</a>
	<a href="/admin/event">イベント情報</a>
	<a href="/admin/worker">人材情報</a>
	<a href="/admin/dispatch">派遣情報</a>
</div>
</body>
</html><?php /**PATH C:\Users\juleo\laravel\gorin_completedversion\resources\views/admin/menu.blade.php ENDPATH**/ ?>