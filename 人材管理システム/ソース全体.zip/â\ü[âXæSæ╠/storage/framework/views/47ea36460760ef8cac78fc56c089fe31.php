<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<link rel="stylesheet" type="text/css" href="/style.css">
</head>
<body>
<div class="wrap">
<a href="/admin/worker" class="back">戻る</a>
<h1>人材情報更新</h1>
<form method="post" action="/admin/worker/<?php echo e($worker->id); ?>">
	<?php echo csrf_field(); ?>
	<?php echo method_field('put'); ?>
	<div class="input">
		<div>氏名<input type="text" name="name" value="<?php echo e($worker->name); ?>"></div>
		<div>メールアドレス<input type="text" name="email" value="<?php echo e($worker->email); ?>"></div>
		<div>パスワード<input type="password" name="password"></div>
		<div>メモ<input type="text" name="memo" value="<?php echo e($worker->memo); ?>"></div>
		<div class="submit"><input type="submit" value="更新"></div>
	</div>
</form>
</div>
</body>
</html><?php /**PATH C:\Users\juleo\laravel\gorin_completedversion\resources\views/admin/worker/edit.blade.php ENDPATH**/ ?>